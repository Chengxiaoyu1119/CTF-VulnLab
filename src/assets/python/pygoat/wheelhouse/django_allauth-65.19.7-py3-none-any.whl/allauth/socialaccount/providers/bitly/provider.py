from __future__ import annotations

from allauth.socialaccount.providers.base import ProviderAccount
from allauth.socialaccount.providers.bitly.views import BitlyOAuth2Adapter
from allauth.socialaccount.providers.oauth2.provider import OAuth2Provider


class BitlyAccount(ProviderAccount):
    def get_profile_url(self):
        return self.account.extra_data.get("profile_url")

    def get_avatar_url(self):
        return self.account.extra_data.get("profile_image")


class BitlyProvider(OAuth2Provider):
    id = "bitly"
    name = "Bitly"
    account_class = BitlyAccount
    oauth2_adapter_class = BitlyOAuth2Adapter

    def extract_uid(self, data):
        """
        Bitly doesn't document `login` as a guaranteed immutable ID, but
        there is no alternative. So we treat it as "stable by policy, not by
        contract."
        """
        return str(data["login"])

    def extract_common_fields(self, data):
        return dict(username=data["login"], name=data.get("full_name"))


provider_classes = [BitlyProvider]
