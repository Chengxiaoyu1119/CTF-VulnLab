-- OA System Database Initialization Script
-- ==========================================

CREATE DATABASE IF NOT EXISTS oa_system DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE oa_system;

-- -------------------------------------------
-- 用户表
-- -------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `real_name` varchar(50) DEFAULT '',
  `email` varchar(100) DEFAULT '',
  `phone` varchar(20) DEFAULT '',
  `avatar` varchar(255) DEFAULT '',
  `dept_id` bigint unsigned DEFAULT 0,
  `status` tinyint DEFAULT 1 COMMENT '1:正常 0:禁用',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_username` (`username`),
  KEY `idx_dept_id` (`dept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------
-- 角色表
-- -------------------------------------------
CREATE TABLE IF NOT EXISTS `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `code` varchar(50) NOT NULL,
  `description` varchar(255) DEFAULT '',
  `status` tinyint DEFAULT 1,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_name` (`name`),
  UNIQUE KEY `idx_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------
-- 权限表
-- -------------------------------------------
CREATE TABLE IF NOT EXISTS `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `code` varchar(100) NOT NULL,
  `type` varchar(20) NOT NULL COMMENT 'menu:菜单 button:按钮 api:接口',
  `parent_id` bigint unsigned DEFAULT 0,
  `path` varchar(255) DEFAULT '',
  `method` varchar(10) DEFAULT '',
  `icon` varchar(50) DEFAULT '',
  `sort` int DEFAULT 0,
  `status` tinyint DEFAULT 1,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------
-- 部门表
-- -------------------------------------------
CREATE TABLE IF NOT EXISTS `departments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `parent_id` bigint unsigned DEFAULT 0,
  `leader_id` bigint unsigned DEFAULT 0,
  `sort` int DEFAULT 0,
  `status` tinyint DEFAULT 1,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------
-- 用户角色关联表
-- -------------------------------------------
CREATE TABLE IF NOT EXISTS `user_roles` (
  `user_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`user_id`, `role_id`),
  KEY `idx_role_id` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------
-- 角色权限关联表
-- -------------------------------------------
CREATE TABLE IF NOT EXISTS `role_permissions` (
  `role_id` bigint unsigned NOT NULL,
  `permission_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`, `permission_id`),
  KEY `idx_permission_id` (`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------
-- 公告表
-- -------------------------------------------
CREATE TABLE IF NOT EXISTS `announcements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `content` text,
  `type` tinyint DEFAULT 1 COMMENT '1:通知 2:公告 3:规章',
  `status` tinyint DEFAULT 1 COMMENT '1:发布 0:草稿',
  `author_id` bigint unsigned DEFAULT 0,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_author_id` (`author_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------
-- 工单表
-- -------------------------------------------
CREATE TABLE IF NOT EXISTS `tickets` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `content` text,
  `type` tinyint DEFAULT 1 COMMENT '1:故障 2:需求 3:咨询',
  `priority` tinyint DEFAULT 1 COMMENT '1:低 2:中 3:高 4:紧急',
  `status` tinyint DEFAULT 1 COMMENT '1:待处理 2:处理中 3:已关闭',
  `creator_id` bigint unsigned DEFAULT 0,
  `assignee_id` bigint unsigned DEFAULT 0,
  `dept_id` bigint unsigned DEFAULT 0,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_creator_id` (`creator_id`),
  KEY `idx_assignee_id` (`assignee_id`),
  KEY `idx_dept_id` (`dept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------
-- 工单评论表
-- -------------------------------------------
CREATE TABLE IF NOT EXISTS `ticket_comments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `ticket_id` bigint unsigned NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  `content` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_ticket_id` (`ticket_id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------
-- 文件表
-- -------------------------------------------
CREATE TABLE IF NOT EXISTS `files` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `path` varchar(500) NOT NULL,
  `size` bigint DEFAULT 0,
  `type` varchar(50) DEFAULT '',
  `folder_id` bigint unsigned DEFAULT 0,
  `uploader_id` bigint unsigned DEFAULT 0,
  `dept_id` bigint unsigned DEFAULT 0,
  `status` tinyint DEFAULT 1,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_folder_id` (`folder_id`),
  KEY `idx_uploader_id` (`uploader_id`),
  KEY `idx_dept_id` (`dept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------
-- 审批表
-- -------------------------------------------
CREATE TABLE IF NOT EXISTS `approvals` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `type` varchar(50) NOT NULL COMMENT 'leave:请假 expense:报销 purchase:采购',
  `content` text,
  `status` tinyint DEFAULT 1 COMMENT '1:待审批 2:已通过 3:已拒绝',
  `applicant_id` bigint unsigned DEFAULT 0,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_applicant_id` (`applicant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------
-- 审批记录表
-- -------------------------------------------
CREATE TABLE IF NOT EXISTS `approval_records` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `approval_id` bigint unsigned NOT NULL,
  `approver_id` bigint unsigned NOT NULL,
  `status` tinyint DEFAULT 1 COMMENT '1:待审批 2:已通过 3:已拒绝',
  `comment` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_approval_id` (`approval_id`),
  KEY `idx_approver_id` (`approver_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------
-- 登录日志表
-- -------------------------------------------
CREATE TABLE IF NOT EXISTS `login_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT 0,
  `username` varchar(50) DEFAULT '',
  `ip` varchar(50) DEFAULT '',
  `user_agent` varchar(500) DEFAULT '',
  `status` tinyint DEFAULT 1 COMMENT '1:成功 0:失败',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------
-- 操作日志表
-- -------------------------------------------
CREATE TABLE IF NOT EXISTS `operation_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT 0,
  `username` varchar(50) DEFAULT '',
  `module` varchar(50) DEFAULT '',
  `action` varchar(50) DEFAULT '',
  `method` varchar(10) DEFAULT '',
  `path` varchar(255) DEFAULT '',
  `ip` varchar(50) DEFAULT '',
  `request` text,
  `response` text,
  `status` int DEFAULT 0,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------------------------------
-- 系统配置表
-- -------------------------------------------
CREATE TABLE IF NOT EXISTS `system_configs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(100) NOT NULL,
  `value` text,
  `type` varchar(20) DEFAULT 'string',
  `remark` varchar(255) DEFAULT '',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ==========================================
-- 初始化数据
-- ==========================================

-- 初始化角色
INSERT INTO `roles` (`id`, `name`, `code`, `description`) VALUES
(1, '系统管理员', 'admin', '系统最高权限管理员'),
(2, '部门主管', 'manager', '部门管理权限'),
(3, '普通员工', 'user', '基础操作权限');

-- 初始化部门
INSERT INTO `departments` (`id`, `name`, `parent_id`, `leader_id`, `sort`) VALUES
(1, '总公司', 0, 1, 1),
(2, '技术部', 1, 2, 2),
(3, '市场部', 1, 0, 3),
(4, '人事部', 1, 0, 4),
(5, '财务部', 1, 0, 5);

-- 初始化用户 (密码: ZSD@admin2025! / manager123 / user123 / 123456)
INSERT INTO `users` (`id`, `username`, `password`, `real_name`, `email`, `phone`, `dept_id`, `avatar`) VALUES
(1, 'admin', '$2b$10$7yXYhZL4Uk7WHoCKLtSO/OPqMfSlrK9aTtSsuHzkfGb1i7l0GR8SK', '系统管理员', 'admin@company.com', '13800000001', 1, '/uploads/avatars/default.png'),
(2, 'manager', '$2a$10$dW2tG8mTp2Ft5AqtempfnOJXRlxU7zxoTgQX8e9QpWiuiTxcOowpS', '张主管', 'manager@company.com', '13800000002', 2, '/uploads/avatars/default.png'),
(3, 'user', '$2a$10$aAUpRyaNC9KBC2sVrv8BROXZ2QvkK14Cv/3pfg7IGnMJFYJLzRHYO', '李员工', 'user@company.com', '13800000003', 2, '/uploads/avatars/default.png'),
(4, 'zhangsan', '$2a$10$aAUpRyaNC9KBC2sVrv8BROXZ2QvkK14Cv/3pfg7IGnMJFYJLzRHYO', '张三', 'zhangsan@company.com', '13800000004', 3, '/uploads/avatars/default.png'),
(5, 'lisi', '$2a$10$aAUpRyaNC9KBC2sVrv8BROXZ2QvkK14Cv/3pfg7IGnMJFYJLzRHYO', '李四', 'lisi@company.com', '13800000005', 4, '/uploads/avatars/default.png'),
(6, 'test', '$2b$10$g2ZoZGPzxQa.ZvMBQLjXMe150c.B2euXxKM7KWS3I6ZC35s3JTrJu', '测试用户', 'test@company.com', '13800000006', 2, '/uploads/avatars/default.png');

-- 初始化用户角色关联
INSERT INTO `user_roles` (`user_id`, `role_id`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 3),
(5, 3),
(6, 3);

-- 初始化权限 (菜单)
INSERT INTO `permissions` (`id`, `name`, `code`, `type`, `parent_id`, `path`, `icon`, `sort`) VALUES
(1, '工作台', 'dashboard', 'menu', 0, '/dashboard', 'DashboardOutlined', 1),
(2, '用户中心', 'user-center', 'menu', 0, '/user-center', 'UserOutlined', 2),
(3, '组织架构', 'organization', 'menu', 0, '/organization', 'ApartmentOutlined', 3),
(4, '部门管理', 'dept-manage', 'menu', 3, '/organization/department', '', 1),
(5, '员工管理', 'staff-manage', 'menu', 3, '/organization/staff', '', 2),
(6, '角色管理', 'role-manage', 'menu', 3, '/organization/role', '', 3),
(7, '公告管理', 'announcement', 'menu', 0, '/announcement', 'NotificationOutlined', 4),
(8, '公告列表', 'announcement-list', 'menu', 7, '/announcement/list', '', 1),
(9, '公告管理', 'announcement-manage', 'menu', 7, '/announcement/manage', '', 2),
(10, '工单系统', 'ticket', 'menu', 0, '/ticket', 'FileTextOutlined', 5),
(11, '我的工单', 'my-ticket', 'menu', 10, '/ticket/list', '', 1),
(12, '文件中心', 'file-center', 'menu', 0, '/file', 'FolderOutlined', 6),
(13, '审批中心', 'approval', 'menu', 0, '/approval', 'AuditOutlined', 7),
(14, '我的申请', 'my-approval', 'menu', 13, '/approval/my', '', 1),
(15, '待审批', 'pending-approval', 'menu', 13, '/approval/pending', '', 2),
(16, '日志管理', 'log-center', 'menu', 0, '/log', 'FileSearchOutlined', 8),
(17, '登录日志', 'login-log', 'menu', 16, '/log/login', '', 1),
(18, '操作日志', 'operation-log', 'menu', 16, '/log/operation', '', 2),
(19, '系统配置', 'system-config', 'menu', 0, '/system', 'SettingOutlined', 9);

-- 管理员拥有所有权限
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES
(1, 1), (1, 2), (1, 3), (1, 4), (1, 5), (1, 6), (1, 7), (1, 8), (1, 9), (1, 10),
(1, 11), (1, 12), (1, 13), (1, 14), (1, 15), (1, 16), (1, 17), (1, 18), (1, 19);

-- 主管权限
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES
(2, 1), (2, 2), (2, 3), (2, 4), (2, 5), (2, 7), (2, 8), (2, 9), (2, 10), (2, 11),
(2, 12), (2, 13), (2, 14), (2, 15);

-- 普通员工权限
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES
(3, 1), (3, 2), (3, 7), (3, 8), (3, 10), (3, 11), (3, 12), (3, 13), (3, 14);

-- 初始化公告
INSERT INTO `announcements` (`title`, `content`, `type`, `status`, `author_id`) VALUES
('关于2025年端午节放假通知', '<p>各部门：</p><p>根据国务院办公厅通知，2025年端午节放假安排如下：</p><p>6月28日至6月30日放假调休，共3天。</p><p>请各部门提前做好工作安排。</p><p>行政部</p><p>2025年6月15日</p>', 1, 1, 1),
('公司信息安全管理制度', '<p>为加强公司信息安全管理，防范信息安全风险，特制定本制度：</p><p>1. 员工不得将公司内部资料外泄</p><p>2. 所有系统密码需定期更换</p><p>3. 禁止在公共网络环境下访问内网系统</p><p>4. 发现安全隐患需立即报告信息安全部门</p>', 2, 1, 1),
('新版OA系统上线通知', '<p>各位同事：</p><p>新版OA系统已于本周上线，请大家注意：</p><p>1. 首次登录请使用默认密码并修改</p><p>2. 如遇问题请提交工单至技术部</p><p>3. 旧系统将于月底关闭</p>', 1, 1, 1);

-- 初始化工单
INSERT INTO `tickets` (`title`, `content`, `type`, `priority`, `status`, `creator_id`, `assignee_id`, `dept_id`) VALUES
('OA系统登录异常', '今天下午使用Chrome浏览器登录OA系统时，输入正确密码后页面一直跳转无法进入，请排查。', 1, 3, 1, 3, 2, 2),
('申请开通VPN权限', '因项目需要，需远程访问公司内网，申请开通VPN权限。', 2, 2, 2, 4, 2, 2),
('打印机无法连接', '3楼打印室的HP打印机无法连接，重启后仍然无法识别，请IT部门协助处理。', 1, 2, 1, 5, 0, 4);

-- 初始化工单评论
INSERT INTO `ticket_comments` (`ticket_id`, `user_id`, `content`) VALUES
(1, 2, '已收到，正在排查中。请问是所有浏览器都无法登录还是只有Chrome？'),
(1, 3, '我试了Edge浏览器也不行，似乎是账号问题。'),
(2, 2, 'VPN权限已开通，请查收邮件中的配置说明。');

-- 初始化审批
INSERT INTO `approvals` (`title`, `type`, `content`, `status`, `applicant_id`) VALUES
('2025年6月请假申请', 'leave', '因个人原因，申请6月20日-6月21日请假2天。', 1, 3),
('差旅费报销申请', 'expense', '6月初出差北京参加技术峰会，总费用3500元（机票1200+酒店1800+交通500）', 2, 4),
('采购申请-开发服务器', 'purchase', '技术部需要采购2台开发服务器，预算约50000元，用于新项目开发测试。', 1, 2);

-- 初始化审批记录
INSERT INTO `approval_records` (`approval_id`, `approver_id`, `status`, `comment`) VALUES
(1, 2, 1, NULL),
(2, 2, 2, '费用合理，同意报销'),
(3, 1, 1, NULL);

-- 初始化系统配置
INSERT INTO `system_configs` (`key`, `value`, `type`, `remark`) VALUES
('site_name', '中盛达信息科技有限公司OA系统', 'string', '站点名称'),
('site_logo', '/uploads/logo.png', 'string', '站点Logo'),
('mail_host', 'smtp.company.com', 'string', '邮件服务器'),
('mail_port', '465', 'string', '邮件端口'),
('mail_user', 'oa-notice@company.com', 'string', '邮件账号'),
('mail_password', 'mail@2025', 'string', '邮件密码'),
('upload_max_size', '10485760', 'number', '上传文件大小限制(字节)'),
('webhook_url', 'https://hooks.company.com/oa-notify', 'string', 'Webhook通知地址'),
('wechat_corp_id', 'wx12345678', 'string', '企业微信CorpID'),
('wechat_secret', 'abcdef123456', 'string', '企业微信Secret');

-- ==========================================
-- 通知模板表
-- ==========================================
CREATE TABLE `notification_templates` (
  `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL COMMENT '模板名称',
  `type` VARCHAR(20) NOT NULL DEFAULT 'email' COMMENT '类型: email/sms/system',
  `subject` VARCHAR(200) NOT NULL DEFAULT '' COMMENT '主题模板',
  `content` TEXT NOT NULL COMMENT '内容模板（Go template语法）',
  `variables` TEXT COMMENT '可用变量说明（JSON）',
  `status` TINYINT NOT NULL DEFAULT 1 COMMENT '1启用 0禁用',
  `creator_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 初始化通知模板
INSERT INTO `notification_templates` (`name`, `type`, `subject`, `content`, `variables`, `status`, `creator_id`) VALUES
('审批通过通知', 'email', '您的{{.TypeName}}已通过', '{{.RealName}}，您好：\n\n您提交的{{.TypeName}}《{{.Title}}》已由{{.ApproverName}}审批通过。\n\n提交时间：{{.CreatedAt}}\n审批时间：{{.ApprovedAt}}\n\n如有疑问请联系您的部门主管。\n\n{{.SiteName}}', '{"RealName":"申请人姓名","TypeName":"审批类型","Title":"审批标题","ApproverName":"审批人","CreatedAt":"提交时间","ApprovedAt":"审批时间","SiteName":"站点名称"}', 1, 1),
('审批驳回通知', 'email', '您的{{.TypeName}}已被驳回', '{{.RealName}}，您好：\n\n很遗憾，您提交的{{.TypeName}}《{{.Title}}》已被{{.ApproverName}}驳回。\n\n驳回原因：{{.Reason}}\n\n请修改后重新提交，如有疑问请联系审批人。\n\n{{.SiteName}}', '{"RealName":"申请人姓名","TypeName":"审批类型","Title":"审批标题","ApproverName":"审批人","Reason":"驳回原因","SiteName":"站点名称"}', 1, 1),
('新工单分配通知', 'system', '您有新的工单待处理', '{{.AssigneeName}}，您好：\n\n有一个新的工单已分配给您：\n\n工单标题：{{.Title}}\n工单类型：{{.TypeName}}\n优先级：{{.Priority}}\n提交人：{{.CreatorName}}\n提交时间：{{.CreatedAt}}\n\n请及时处理。\n\n{{.SiteName}}', '{"AssigneeName":"处理人姓名","Title":"工单标题","TypeName":"工单类型","Priority":"优先级","CreatorName":"提交人","CreatedAt":"提交时间","SiteName":"站点名称"}', 1, 1),
('密码重置通知', 'email', '密码重置验证码', '{{.Username}}，您好：\n\n您正在重置登录密码，验证码为：{{.Code}}\n\n验证码有效期为{{.ExpireMinutes}}分钟，请勿将验证码告知他人。\n\n如非本人操作，请忽略此邮件。\n\n{{.SiteName}}', '{"Username":"用户名","Code":"验证码","ExpireMinutes":"有效期(分钟)","SiteName":"站点名称"}', 1, 1),
('系统公告通知', 'system', '【公告】{{.Title}}', '{{.RealName}}，您好：\n\n系统发布了新公告：\n\n标题：{{.Title}}\n发布人：{{.AuthorName}}\n发布时间：{{.CreatedAt}}\n\n{{.Summary}}\n\n请登录系统查看详情。\n\n{{.SiteName}}', '{"RealName":"收件人姓名","Title":"公告标题","AuthorName":"发布人","CreatedAt":"发布时间","Summary":"内容摘要","SiteName":"站点名称"}', 1, 1);

-- 通知模板权限
INSERT INTO `permissions` (`id`, `name`, `code`, `type`, `parent_id`, `path`, `icon`, `sort`) VALUES
(20, '系统管理', 'system-manage', 'menu', 0, '/system', 'SettingOutlined', 9),
(21, '通知模板', 'notification-template', 'menu', 20, '/system/notification', '', 2);

-- 更新系统配置权限：改为系统管理的子菜单
UPDATE `permissions` SET `parent_id` = 20, `sort` = 1 WHERE `id` = 19;

-- 管理员增加通知模板权限
INSERT INTO `role_permissions` (`role_id`, `permission_id`) VALUES
(1, 20), (1, 21);
